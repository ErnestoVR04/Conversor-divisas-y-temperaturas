package modulo;

import javax.swing.JOptionPane;

import conversorDivisas.funcionDivisas;
import conversorTemperatura.funcionTemperatura;

public class main {
	funcionDivisas fDivisas = new funcionDivisas();
	funcionTemperatura fTemperatura = new funcionTemperatura();
	
	public static void main(String[] args) {
		main p = new main();
		
		while(true) {
			String[] conversores = {"Divisas","Temperaturas"};
			String selection = (String) JOptionPane.showInputDialog(null, "Elige un conversor", "Menu", JOptionPane.QUESTION_MESSAGE, null, conversores,"");
			double cantidad = Double.parseDouble(JOptionPane.showInputDialog("Ingresa la cantidad deseada: "));
			switch(selection) {
				case "Divisas": 
					p.fDivisas.convertirDivisas(cantidad);
					break;
					
				case "Temperaturas":
					p.fTemperatura.ConvertirTemperatura(cantidad);
					break;
			}
			if(JOptionPane.showConfirmDialog(null, "Estas seguro de salir","Salir",JOptionPane.YES_NO_OPTION)==0) {
				System.exit(0);}
		}
	} 
}

/**
 * 
 */
/**
 * 
 */
module Conversor_divisas {
	requires java.desktop;
}
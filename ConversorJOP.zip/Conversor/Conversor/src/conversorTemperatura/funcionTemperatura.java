package conversorTemperatura;

import javax.swing.JOptionPane;

public class funcionTemperatura {
	Temperaturas temperaturas =  new Temperaturas();
	
	public void ConvertirTemperatura(double cantidad) {
		String[] tiposTemperaturas = {"Celsius(C) a Kelvin(K)", "Celsius(C) a Fahrenheit(F)", "Kelvin(K) a Fahrenheit(F)","Kelvin(K) a Celsius(C)","Fahrenheit(F) a Kelvin(K)","Fahrenheit(F) a Celsius(C)"};
		String temperaturaSeleccionada = (String) JOptionPane.showInputDialog(null, "Elige el tipo de conversion", "Temperaturas", JOptionPane.QUESTION_MESSAGE, null, tiposTemperaturas,"Celsius(C) a Fahrenheit(F)");
		switch(temperaturaSeleccionada) {
			case "Celsius(C) a Kelvin(K)":
				temperaturas.convertirCelsius_Kelvin(cantidad);
				break;
			case "Celsius(C) a Fahrenheit(F)":
				temperaturas.convertirCelsius_Fahrenheit(cantidad);
				break;
			case "Kelvin(K) a Fahrenheit(F)":
				temperaturas.convertirKelvin_Fahrenheit(cantidad);
				break;
			case "Kelvin(K) a Celsius(C)":
				temperaturas.convertirFahrenheit_Celcius(cantidad);
				break;
			case "Fahrenheit(F) a Kelvin(K)":
				temperaturas.convertirFahrenheit_Kelvin(cantidad);
				break;
			case "Fahrenheit(F) a Celsius(C)":
				temperaturas.convertirFahrenheit_Celcius(cantidad);
				break;
		}
	
	}

}

package conversorTemperatura;

import javax.swing.JOptionPane;

public class Temperaturas {
	public void convertirCelsius_Kelvin(double cantidad) {
		double total = (double) (cantidad+273.15);
		JOptionPane.showMessageDialog(null, "Total: "+String.format("%.02f", total)+"°");
	}
	public void convertirCelsius_Fahrenheit(double cantidad) {
		double total = (double)cantidad*9/5+32;
		JOptionPane.showMessageDialog(null, "Total: "+String.format("%.02f", total)+"°");
	}
	public void convertirKelvin_Fahrenheit(double cantidad) {
		double total = (double) (cantidad*9/5-459.67); 
		JOptionPane.showMessageDialog(null, "Total: "+String.format("%.02f", total)+"°");
	}
	public void convertirKelvin_Celsius(double cantidad) {
		double total = (double)(cantidad-273.15);
		JOptionPane.showMessageDialog(null, "Total: "+String.format("%.02f", total)+"°");
	}
	public void convertirFahrenheit_Kelvin(double cantidad) {
		double total = (double) ((cantidad+459.67)*5/9);
		JOptionPane.showMessageDialog(null, "Total: "+String.format("%.02f", total)+"°");
	}
	public void convertirFahrenheit_Celcius(double cantidad) {
		double total = (double)(cantidad-32)*5/9;
		JOptionPane.showMessageDialog(null, "Total: "+String.format("%.02f", total)+"°");
	}
	
	
}

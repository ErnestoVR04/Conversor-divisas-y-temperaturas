package conversorDivisas;

import javax.swing.JOptionPane;

public class funcionDivisas {
	
	Divisas divisas = new Divisas();
	
	public void convertirDivisas(double cantidad) {
		String[] tiposDivisas = {"Pesos a Dólares","Pesos a Euros","Pesos a Libras","Pesos a Yen Jápones","Pesos a Won sul-coreano","Dólares a Pesos","Euros a Pesos","Libras a Pesos","Yen Jápones a Pesos","Won sul-coreano a Pesos"};
		String divisaSeleccionada = (String) JOptionPane.showInputDialog(null, "Elige el tipo de cambio", "Divisas", JOptionPane.QUESTION_MESSAGE, null, tiposDivisas,"");
		switch(divisaSeleccionada) {
			case "Pesos a Dólares":
				divisas.convertirPesos_Dolares(cantidad);
				break;
			case "Pesos a Euros":
				divisas.convertirPesos_Euros(cantidad);
				break;
			case "Pesos a Libras":
				divisas.convertirPesos_Libras(cantidad);
				break;
			case "Pesos a Yen Jápones":
				divisas.convertirPesos_Yen(cantidad);
				break;
			case "Pesos a Won sul-coreano":
				divisas.convertirPesos_Won(cantidad);
				break;
			case "Dólares a Pesos":
				divisas.convertirDolares_Pesos(cantidad);
				break;
			case "Euros a Pesos":
				divisas.convertirEuros_Pesos(cantidad);
				break;
			case "Libras a Pesos":
				divisas.convertirLibras_Pesos(cantidad);
				break;
			case "Yen Jápones a Pesos":
				divisas.convertirYen_Pesos(cantidad);
				break;
			case "Won sul-coreano a Pesos":
				divisas.convertirWon_Pesos(cantidad);
				break;
		}
	}
}

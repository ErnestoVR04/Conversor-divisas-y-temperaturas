package conversorDivisas;

import javax.swing.JOptionPane;

public class Divisas {
	//pesos a divisa
	public void convertirPesos_Dolares(double cantidad) {
		double total = (cantidad/17.3286);
		JOptionPane.showMessageDialog(null, "Total: "+String.format("%.02f", total));
	}
	public void convertirPesos_Euros(double cantidad) {
		double total = (cantidad/18.98);
		JOptionPane.showMessageDialog(null, "Total: "+String.format("%.02f", total));
	}
	public void convertirPesos_Libras(double cantidad) {
		double total = (cantidad/22.03);
		JOptionPane.showMessageDialog(null, "Total: "+String.format("%.02f", total));
	}
	public void convertirPesos_Yen(double cantidad) {
		double total = (cantidad/0.12);
		JOptionPane.showMessageDialog(null, "Total: "+String.format("%.02f", total));
	}
	public void convertirPesos_Won(double cantidad) {
		double total = (cantidad/0.013);
		JOptionPane.showMessageDialog(null, "Total: "+String.format("%.02f", total));
	}
	
	//Divisa a pesos
	public void convertirDolares_Pesos(double cantidad) {
		double total=(float) (17.3286*cantidad);
		JOptionPane.showMessageDialog(null, "Total: "+String.format("%.02f", total));
	}
	public void convertirEuros_Pesos(double cantidad) {
		double total=(float) (18.98*cantidad);
		JOptionPane.showMessageDialog(null, "Total: "+String.format("%.02f", total));
	}
	public void convertirLibras_Pesos(double cantidad) {
		double total=(float) (22.03*cantidad);
		JOptionPane.showMessageDialog(null, "Total: "+String.format("%.02f", total));
	}
	public void convertirYen_Pesos(double cantidad) {
		double total=(float) (0.12*cantidad);
		JOptionPane.showMessageDialog(null, "Total: "+String.format("%.02f", total));
	}
	public void convertirWon_Pesos(double cantidad) {
		double total=(float) (0.013*cantidad);
		JOptionPane.showMessageDialog(null, "Total: "+String.format("%.02f", total));
	}
	
	
}
